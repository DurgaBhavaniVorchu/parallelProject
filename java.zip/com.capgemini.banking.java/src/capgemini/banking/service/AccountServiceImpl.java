package capgemini.banking.service;
import java.util.*;

import capgemini.banking.bean.Account;
import capgemini.banking.bean.Address1;
import capgemini.banking.bean.Customer;
import capgemini.banking.exception.AccountNotFoundException;
import capgemini.banking.exception.InsufficientBalanceException;

public class AccountServiceImpl implements AccountService{
	Scanner sc = new Scanner(System.in);
	HashMap<Long, Account> map_Account = new HashMap<Long, Account>(); 
	double openingBalance;
	
	Customer customer;
	Account accountObj;
	
	public Account createAccount() {

		System.out.print("Enter firstName: ");
		String firstName = sc.next();
		System.out.print("Enter lastName: ");
		String lastName = sc.next();
		System.out.print("Enter Mobile No: ");
		long mobNo = 0 ;
		try{
			int count=0;
			mobNo = sc.nextLong();
			long ref = mobNo;
			
			while(ref>0){
				ref =ref/10;
				count++;
			}
			if(count >10||count<10) throw new Exception("Enter mobile number:"+createAccount());
		} catch(Exception ex) {
			System.out.println("phone number should not be above or below 10 digits....");
		}
		
		System.out.print("Enter Email Id: ");
		String email = sc.next();
		Customer customerObj = new Customer(firstName, lastName, mobNo, email);
		System.out.println("Enter the details of your address:");
		System.out.println("Enter Door Number:");
		String dNo = sc.next();
		System.out.println("Enter Street name:");
		String street = sc.next();
		System.out.println("Enter City name:");
		String city = sc.next();
		System.out.println("Enter PinCode number:");
		String pinCode = sc.next();
		Address1 addressObj = new Address1(dNo, street, city, pinCode);
		customerObj.setAddress(addressObj);
		long accNo = mobNo - 4567;
		System.out.println("Enter Account Type:");
		String accType = sc.next();
		System.out.print("Enter Opening Balance: ");
		openingBalance = sc.nextDouble();
		Account accountObj = new Account(accNo, accType, openingBalance);
		System.out.println("Successfully created your account...");
		System.out.println(customerObj.toString());
		System.out.println(accountObj.toString());
		return map_Account.put(accNo, accountObj); 
	}

	public void showBalance()throws AccountNotFoundException  {
		Account accountType = null;
		System.out.println("enter account number: ");
		long account_number = sc.nextLong();
		if(accountObj == null) throw new AccountNotFoundException(account_number+" does not exists...");
		Set<Long> keySet = map_Account.keySet();
		Iterator<Long> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			long acc = iterator.next();
			if (map_Account.containsKey(account_number)) {
				accountType = map_Account.get(account_number);
				System.out.println("Your Current Balance id: "+accountType.getCurrentBalance());
			}
		}
	}

	public void deposit() throws AccountNotFoundException{
		Account accountType = null;
		System.out.println("enter account number: ");
		long account_number = sc.nextLong();
		if(accountObj == null) throw new AccountNotFoundException(account_number+" does not exists...");
		Set<Long> keySet = map_Account.keySet();
		Iterator<Long> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			long acc = iterator.next();
			if (map_Account.containsKey(account_number)) {
				System.out.println("Enter deposit amount");
				double depAmount = sc.nextDouble();
				accountType = map_Account.get(account_number);
				double currentBalance = accountType.getCurrentBalance();
				currentBalance += depAmount;
				accountType.setCurrentBalance(currentBalance);
				System.out.println("Your Amount is Successfully deposited.....");
			}
		}
	}

	public void withDraw() throws AccountNotFoundException, InsufficientBalanceException{
		Account accountType = null;
		System.out.println("enter account number: ");
		long account_number = sc.nextLong();
		if(accountObj == null) throw new AccountNotFoundException(account_number+" does not exists...");
		Set<Long> keySet = map_Account.keySet();
		Iterator<Long> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			long acc = iterator.next();
			if (map_Account.containsKey(account_number)) {
				System.out.println("Enter withDraw amount");
				double withDrawAmount = sc.nextDouble();
				accountType = map_Account.get(account_number);
				double currentBalance = accountType.getCurrentBalance();
				if(currentBalance < withDrawAmount) throw new InsufficientBalanceException("Insufficient Balance...");
				currentBalance -= withDrawAmount;
				accountType.setCurrentBalance(currentBalance);
				System.out.println("Your amount is successfully withDrawl from your account...");
			}
		}
		
	}

	public void fundTransfer() throws AccountNotFoundException, InsufficientBalanceException{
		Account accountType = null;
		System.out.println("enter account number: ");
		long account_number = sc.nextLong();
		if(accountObj == null) throw new AccountNotFoundException(account_number+" does not exists...");
		System.out.println("Enter destination Account number");
		long account_number2 = sc.nextLong();
		Set<Long> keySet = map_Account.keySet();
		Iterator<Long> iterator = keySet.iterator();
		while (iterator.hasNext()) {
			long acc = iterator.next();
			if (map_Account.containsKey(account_number)) {
				System.out.println("Enter transfer amount");
				double tranAmount = sc.nextDouble();
				accountType = map_Account.get(account_number);
				double currentBalance = accountType.getCurrentBalance();
				if(currentBalance < tranAmount) throw new InsufficientBalanceException("Insufficient Balance...");
				currentBalance -= tranAmount;
				accountType.setCurrentBalance(currentBalance);
				System.out.println("Your amount is successfully transfered to your destination account...");
			}
		}
		
	}
	
	public Collection<Account> getTransaction(){
		return map_Account.values();
	}
}
