package capgemini.banking.bean;

public class Account {

	private long account_number;
	private String accountType;
	private double openingBalance;
	private double currentBalance;

	public Account(long account_number, String accountType, double openingBalance) {
		super();
		setAccount_number(account_number);
		setAccountType(accountType);
		setOpeningBalance(openingBalance);
		setCurrentBalance(openingBalance);
	}

	public Account(long account_number) {
		super();
		this.account_number = account_number;
	}

	public long getAccount_number() {
		return account_number;
	}

	public void setAccount_number(long account_number) {
		this.account_number = account_number;
	}

	public String getAccountType() {
		return accountType;
	}

	private void setAccountType(String accountName) {
		this.accountType = accountName;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	private void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public double getCurrentBalance() {
		return currentBalance;
	}

	public void setCurrentBalance(double currentBalance) {
		this.currentBalance = currentBalance;
	}

	@Override
	public String toString() {
		return "Account [account_number=" + account_number + ", accountType=" + accountType + ", openingBalance="
				+ openingBalance + ", CurrentBalance: " + currentBalance + "]";
	}
}